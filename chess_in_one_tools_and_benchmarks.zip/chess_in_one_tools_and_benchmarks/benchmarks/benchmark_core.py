
import time, tracemalloc
from chess import Board

def benchmark(provider, samples):
    latencies = []
    legal = 0
    total = 0
    board = Board()

    tracemalloc.start()
    t_start = time.time()

    for sample in samples:
        t0 = time.time()
        text = provider.run(sample)
        latencies.append(time.time() - t0)

        try:
            board.push_san(text)
            legal += 1
        except:
            pass

        total += 1

    elapsed = time.time() - t_start
    peak_mem = tracemalloc.get_traced_memory()[1] / (1024*1024)
    tracemalloc.stop()

    return {
        "avg_latency_ms": (sum(latencies)/len(latencies))*1000,
        "legal_rate": legal/total,
        "total_time_s": elapsed,
        "peak_memory_mb": peak_mem
    }
