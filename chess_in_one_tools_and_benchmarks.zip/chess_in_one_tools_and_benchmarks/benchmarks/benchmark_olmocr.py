
from providers.olmocr_provider import OlmOCRProvider
from benchmark_core import benchmark
import glob, cv2

samples = [cv2.imread(p) for p in glob.glob("data/pages/*.png")]
provider = OlmOCRProvider()

results = benchmark(provider, samples)
print("olmOCR Results:", results)

provider.shutdown()
