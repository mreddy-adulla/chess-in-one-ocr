
from providers.trocr_provider import TrOCRProvider
from benchmark_core import benchmark
import glob, cv2

samples = [cv2.imread(p) for p in glob.glob("data/cells/*.png")]
provider = TrOCRProvider()

results = benchmark(provider, samples)
print("TrOCR Results:", results)

provider.shutdown()
