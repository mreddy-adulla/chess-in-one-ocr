
import cv2
from tools.cell_extractor_auto import extract_cells_auto

def test_extraction_runs(tmp_path):
    img = cv2.imread("tests/sample_scoresheet.png")
    out = tmp_path / "cells"
    out.mkdir()
    count = extract_cells_auto("tests/sample_scoresheet.png", str(out))
    assert count > 0
