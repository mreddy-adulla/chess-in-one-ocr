
import cv2, os
from grid_detector import detect_grid

def extract_cells_auto(image_path, out_dir, debug=False):
    os.makedirs(out_dir, exist_ok=True)
    img = cv2.imread(image_path)
    cells, grid = detect_grid(img)

    base = os.path.splitext(os.path.basename(image_path))[0]
    count = 0

    for i, (x,y,w,h) in enumerate(cells):
        cell = img[y:y+h, x:x+w]
        if cell.size == 0:
            continue
        out = os.path.join(out_dir, f"{base}_cell_{i:05d}.png")
        cv2.imwrite(out, cell)
        count += 1

    if debug:
        debug_img = img.copy()
        for (x,y,w,h) in cells:
            cv2.rectangle(debug_img, (x,y), (x+w,y+h), (0,255,0), 1)
        cv2.imwrite(os.path.join(out_dir, f"{base}_debug.png"), debug_img)

    return count
