
import argparse, glob, os
from cell_extractor_auto import extract_cells_auto

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--debug", action="store_true")
    args = p.parse_args()

    imgs = []
    if os.path.isdir(args.input):
        imgs = glob.glob(os.path.join(args.input, "*.png"))
    else:
        imgs = [args.input]

    total = 0
    for img in imgs:
        total += extract_cells_auto(img, args.output, args.debug)

    print(f"Extracted {total} cells")

if __name__ == "__main__":
    main()
