
import cv2
import numpy as np

def detect_grid(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    thresh = cv2.adaptiveThreshold(
        blur, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        11, 2
    )

    horizontal = thresh.copy()
    vertical = thresh.copy()

    h, w = thresh.shape
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (w//15, 1))
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, h//15))

    horizontal = cv2.morphologyEx(horizontal, cv2.MORPH_OPEN, horizontal_kernel)
    vertical = cv2.morphologyEx(vertical, cv2.MORPH_OPEN, vertical_kernel)

    grid = cv2.add(horizontal, vertical)
    contours, _ = cv2.findContours(grid, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    cells = []
    for c in contours:
        x, y, cw, ch = cv2.boundingRect(c)
        if cw > 20 and ch > 20:
            cells.append((x, y, cw, ch))

    cells = sorted(cells, key=lambda b: (b[1], b[0]))
    return cells, grid
